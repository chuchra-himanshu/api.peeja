import ENV_CONSTANTS from "./env.constants";

export default {
  ENV_CONSTANTS,
};
